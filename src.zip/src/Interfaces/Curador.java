package Interfaces;
import team.Character;

public interface Curador {
	void cureFriend(Character friend);
}

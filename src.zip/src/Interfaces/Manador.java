package Interfaces;
import team.Character;

public interface Manador {
	void manaFriend(Character friend);
}

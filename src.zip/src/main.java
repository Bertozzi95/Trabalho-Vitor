/*
 * Autores: Joao Pedro Junqueira Candido - 8504094
 * Vitor Bertozzi da Silva - 8622401
 * 
 * cria um character
 * distribui suas skills
 * da XP a ele
 * cria 4 items para cada char
 * aumenta seu espaco no inventorio
 * adiciona 4 itens ao char
 */
import items.*;
import team.*;

public class main {
	public static void main(String[] args) {
		Knight char1 = new Knight("Dragao Vermelho da Perdicao",7);
		Thief char2 = new Thief("Cobra Sombria das Trevas",6);
		Wizard char3 = new Wizard("Mago Branco Podereso",5);
		Knight char4 = new Knight("Samurai Yoko do Reino Perdido",8);
		Thief char5 = new Thief("Ladrao Malandro",6);
		Wizard char6 = new Wizard("Feiticeiro Destruidor de Carvalho",7);
		Knight char7 = new Knight("Guerreiro do Pudim",9);
		Thief char8 = new Thief("Hobbit Grande",5);
		
		char1.setConstitution(27);
		char2.setDexterity(30);
		char3.setSpeed(22);
		char4.setStrenght(36);
		char5.setConstitution(32);
		char6.setDexterity(28);
		char7.setSpeed(25);
		char8.setStrenght(30);
		
		char1.addXP(20);
		char2.addXP(15);
		char3.addXP(35);
		char4.addXP(8);
		char5.addXP(25);
		char6.addXP(30);
		char7.addXP(12);
		char8.addXP(20);
		
		Armor item1 = new Armor("Machado da Morte",200,6,4);
		Armor item2 = new Armor("Escudo Tora de Madeira",300,1,5);
		Armor item3 = new Armor("Chave da Perdicao",1000,8,8);
		Armor item4 = new Armor("Pacote de Forca",345,9,6);
		Armor item5 = new Armor("Calca de Platina do Horror",632,3,6);
		Armor item6 = new Armor("Armadura de Runa Efilca",642,5,9);
		Weapon item7 = new Weapon("Armadura da Lava de Mordor",122,2,11);
		Weapon item8 = new Weapon("Luva de Gelo Mistico",963,7,2);
		Weapon item9 = new Weapon("Chifre da Cabra do Inferno",805,4,4);
		Weapon item10 = new Weapon("Anel de Magia Negra",529,6,11);
		Weapon item11= new Weapon("Botas da Agilidade do Espadachim",241,8,4);
		Weapon item12 = new Weapon("Saia de Prata e Ouro",901,2,8);
		Weapon item13 = new Weapon("Cavalo de Agilidade Rara",107,7,5);
		Weapon item14 = new Weapon("Cela Lendaria do Cavalo Lendario",284,6,10);
		Weapon item15 = new Weapon("Runa Misteriosa Numero 8",672,2,15);
		Weapon item16 = new Weapon("Magia dos Ancestrais Celticos",289,7,18);
		
		HealthPotion pocao1 = new HealthPotion("Pocao Grande de Vida",50,50);
		ManaPotion pocao2 = new ManaPotion("Pocao Grande de Mana",50,50);
		HealthPotion pocao3 = new HealthPotion("Pocao Grande de Vida",50,50);
		ManaPotion pocao4 = new ManaPotion("Pocao Grande de Mana",50,50);
		HealthPotion pocao5 = new HealthPotion("Pocao Grande de Vida",50,50);
		ManaPotion pocao6 = new ManaPotion("Pocao Grande de Mana",50,50);
		HealthPotion pocao7 = new HealthPotion("Pocao Grande de Vida",50,50);
		ManaPotion pocao8 = new ManaPotion("Pocao Grande de Mana",50,50);
		
		char1.setSpaces(10);
		char2.setSpaces(10);
		char3.setSpaces(10);
		char4.setSpaces(10);
		char5.setSpaces(10);
		char6.setSpaces(10);
		char7.setSpaces(10);
		char8.setSpaces(10);
		
		char1.addItem(item1);
		char2.addItem(item2);
		char3.addItem(item3);
		char4.addItem(item4);
		char5.addItem(item5);
		char6.addItem(item6);
		char7.addItem(item7);
		char8.addItem(item8);
		char1.addItem(item9);
		char2.addItem(item10);
		char3.addItem(item11);
		char4.addItem(item12);
		char5.addItem(item13);
		char6.addItem(item14);
		char7.addItem(item15);
		char8.addItem(item16);
		
		char1.addItem(pocao1);
		char2.addItem(pocao2);
		char3.addItem(pocao3);
		char4.addItem(pocao4);
		char5.addItem(pocao5);
		char6.addItem(pocao6);
		char7.addItem(pocao7);
		char8.addItem(pocao8);

		char1.equipItem(item1);
		char2.equipItem(item2);
		char3.equipItem(item3);
		char4.equipItem(item4);
		char5.equipItem(item5);
		char6.equipItem(item6);
		char7.equipItem(item7);
		char8.equipItem(item8);
		char1.equipItem(item9);
		char2.equipItem(item10);
		char3.equipItem(item11);
		char4.equipItem(item12);
		char5.equipItem(item13);
		char6.equipItem(item14);
		char7.equipItem(item15);
		char8.equipItem(item16);
		
		
		Team team1 = new Team("Good",Color.white);
		Team team2 = new Team("Evil",Color.red);
		
		team1.addChar(char1);
		team1.addChar(char2);
		team1.addChar(char3);
		team1.addChar(char4);
		team2.addChar(char5);
		team2.addChar(char6);
		team2.addChar(char7);
		team2.addChar(char8);
		
		team1.attack(team2);
		team2.attack(team1);
		
		System.out.println("");
		System.out.println(char1.getName()+" HP: "+char1.getHP()+" Mana: "+char1.getMP());
		System.out.println(char2.getName()+" HP: "+char2.getHP()+" Mana: "+char2.getMP());
		System.out.println(char4.getName()+" HP: "+char4.getHP()+" Mana: "+char4.getMP());
		
		pocao1.cureFriend(char2);
		pocao2.use();
		char3.cureFriend(char4);
		char3.manaFriend(char1);
		
		

	}

}

package items;

public class Weapon extends Item{
	
	protected int attackpts;
	protected double range;

	public Weapon(String name, double price,int attackpts,double range) {
		super(name, price);
		
		this.attackpts = (attackpts>9)?9:attackpts;
		this.attackpts = (this.attackpts<1)?1:this.attackpts;
		
		this.range = range;
	}
	public Weapon(Weapon weapon){
		super(weapon);
		this.attackpts = weapon.attackpts;
		this.range = weapon.range;
		
	}
	@Override
	public int getAtackPts() {
		return attackpts;
	}
	@Override
	public int getDefensePts() {return 0;}
	public double getRange() {
		return range;
	}
}

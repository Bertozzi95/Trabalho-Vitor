/*
 * Autor: Joao Pedro Junqueira Candido - 8504094
 */
package items;
import team.Character;

public abstract class Item {
	protected String name;
	protected double price;
	protected Character owner;
	

	public Item(String name,double price){
		this.name = name;
		this.price = price;
		this.writeItem();
		this.owner=null;
		
	}
	public Character getOwner() {
		return owner;
	}
	public void setOwner(Character owner) {
		this.owner = owner;
	}
	public Item(Item item){
		this.name = item.name;
		this.price = item.price;
		this.writeItem();
		this.owner=null;
	}
	public String getName(){
		return name;
	}
	public double getPrice(){
		return price;
	}
	public void use(){}
	abstract public int getDefensePts();
	abstract public int getAtackPts();
	
	
	public void writeItem(){
		System.out.println("Item: "+ name+" preco: "+price);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(price) != Double
				.doubleToLongBits(other.price))
			return false;
		return true;
	}
}

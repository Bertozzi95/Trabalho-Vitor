package items;

abstract class Potion extends Item{

	public int restorepts;
	
	
	public Potion(Potion potion) {
		super(potion);
		this.restorepts = potion.restorepts;
	}
	public Potion(String name,double price, int restorepts){
		super(name,price);
		this.restorepts = restorepts;
	}
	
	
	public int getRestorePts(){
		return restorepts;
	}
	abstract public void use();
	public int getDefensePts(){return 0;}
	public int getAtackPts(){return 0;}

}

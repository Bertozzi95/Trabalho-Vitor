/*
 * Autor: Joao Pedro Junqueira Candido - 8504094
 */
package items;
import java.util.ArrayList;
import team.Character;

public class Inventory {
	private int spaces;
	private double gold;
	private ArrayList<Dupla<Item,Boolean>> items;
	private ArrayList<Item> equipedArmor;
	private ArrayList<Item> equipedWeapon;
	private Character owner;
	
	public Inventory(Character owner){
		this.owner = owner;
		this.gold = 0;
		this.spaces = 0;
		this.items = new ArrayList<Dupla<Item,Boolean>>();
		this.equipedArmor = new ArrayList<Item>();
		this.equipedWeapon = new ArrayList<Item>();
	}
	public double getTotalGold(){
		return gold;
	}
	public int getAvailableSpace(){
		return (spaces-items.size());
	}
	public void spendGold(double gold){
		this.gold -= gold;
	}
	public void earnGold(double gold){
		this.gold += gold;
	}
	public void setSpaces(int spaces){
		this.spaces = spaces;
	}
	public Item searchItem(String item){
		Item tempItem = null;
		for(int i=0;i<items.size();i++){
			if( (tempItem = items.get(i).getItem1()).getName().equals(item)){
				return tempItem;
			}
		}
		return tempItem;
	}
	public Item searchItem(int item){
		return this.items.get(item).getItem1();
	}
	public boolean searchItem(Item item){
		for(int i=0;i<items.size();i++){
			if(items.get(i).getItem1().equals(item)){
				return true;
			}
		}
		return false;
	}
	//insere item somente se houver espaco
	public void insertItem(Item item){
		if(this.getAvailableSpace() > 0){
			item.setOwner(this.getOwner());
			Dupla<Item,Boolean> dupla = new Dupla<Item,Boolean>(item,false);
			this.items.add(dupla);
		}else{
			System.out.println("Nao ha espaco disponivel para adicionar o item");
		}
	}
	public Boolean isEquiped(Item item){
		Dupla<Item,Boolean> dupla;
		for(int i=0;i<items.size();i++){
			if( (dupla = items.get(i)).getItem1().equals(item)){
				return dupla.getItem2();
			}
		}
		return false;
	}
	public void equip(Item item){
		Dupla<Item,Boolean> dupla;
		Item it;
		for(int i=0;i<items.size();i++){
			if( (dupla = items.get(i)).getItem1().equals(item)){
				it = dupla.getItem1();
				dupla.setItem2(true);
				if(it instanceof Armor){
					System.out.println("Armadura equipada: "+dupla.getItem1().getName());
					if(this.equipedArmor.size()==1){
						this.unequip(this.equipedArmor.get(0));
						this.equipedArmor.remove(0);
						}
					this.equipedArmor.add(0, it);
					
				}else{
					System.out.println("Arma equipada: "+dupla.getItem1().getName());
					if(this.equipedWeapon.size()==2){
						this.unequip(this.equipedWeapon.get(1));
						this.equipedWeapon.remove(1);
						}
					this.equipedWeapon.add(it);
				}
			}
		}
	}
	public void unequip(Item item){
		Dupla<Item,Boolean> dupla;
		for(int i=0;i<items.size();i++){
			if( (dupla = items.get(i)).getItem1().equals(item)){
				dupla.setItem2(false);
			}
		}
	}
	public void removeItem(String item){
		for(int i=0;i<items.size();i++){
			if(items.get(i).getItem1().getName().equals(item)){
				System.out.println("Item removido: "+item);
				items.remove(i);
			}
		}
	}
	public void removeItem(int item){
		this.items.remove(item);
	}
	public int numberOfItems(){
		return this.items.size();
	}
	public Character getOwner() {
		return owner;
	}

}

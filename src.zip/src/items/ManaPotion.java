package items;
import Interfaces.Manador;
import team.Character;

public class ManaPotion extends Potion implements Manador{

	public ManaPotion(String name, double price, int restorepts) {
		super(name, price, restorepts);
	}

	@Override
	public void use() {
		if(owner != null && owner.searchItem(this)){
			owner.addMP(restorepts);
			System.out.println("Pocao usada em "+owner.getName()+", sua MP: "+owner.getMP());
			owner.deleteItem(this);
			this.owner=null;
		}else{
			System.out.println("O character nao possui este item");
		}
	}
	
	public void manaFriend(Character friend){
		if(owner != null && owner.searchItem(this)){
			friend.addMP(restorepts);
			System.out.println("Pocao usada em "+owner.getName()+", sua MP: "+owner.getMP());
			owner.deleteItem(this);
			this.owner=null;
		}else{
			System.out.println("O character nao possui este item");
		}
	}
	

}

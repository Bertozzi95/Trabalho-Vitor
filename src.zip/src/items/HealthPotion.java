package items;
import Interfaces.Curador;
import team.Character;

public class HealthPotion extends Potion implements Curador{

	public HealthPotion(String name, double price, int restorepts) {
		super(name, price, restorepts);
	}

	@Override
	public void use() {
		if(owner != null && owner.searchItem(this)){
			owner.addHP(restorepts);
			System.out.println("Pocao usada em "+owner.getName()+", sua HP: "+owner.getHP());
			owner.deleteItem(this);
			this.owner=null;
		}else{
			System.out.println("O character nao possui este item");
		}
	}
	
	public void cureFriend(Character friend){
		if(owner != null && owner.searchItem(this)){
			friend.addHP(restorepts);
			System.out.println("Pocao usada em "+friend.getName()+", sua HP: "+friend.getHP());
			owner.deleteItem(this);
			this.owner=null;
		}else{
			System.out.println("O character nao possui este item");
		}
	}

}

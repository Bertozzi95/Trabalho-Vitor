package items;
import java.lang.Math;

import team.Character;

public class Armor extends Item{

	protected int defensepts;
	protected double weight;

	public Armor(Armor armor) {
		super(armor);
		
		this.defensepts = armor.defensepts;
		this.weight = armor.weight;
	}

	public Armor(String name, double price,int defensepts,double weight) {
		super(name, price);
		
		this.defensepts = (defensepts>20)?20:defensepts;
		this.defensepts = (this.defensepts<1)?1:this.defensepts;
		
		double w;
		w = (weight>20)?20:weight;
		w = (w<1)?1:w;
		this.weight = w;
	}
	
	public void setModifiedSpeed(){
		double modifiedSpeed = (this.owner.getSpeed() * (Math.sqrt(this.weight)/10));
		System.out.println("ModifiedSpeed: "+modifiedSpeed);
		this.owner.setModifiedSpeed(modifiedSpeed);
	}
	@Override
	public void setOwner(Character owner) {
		super.setOwner(owner);
		this.setModifiedSpeed();
	}
	@Override
	public int getDefensePts() {
		return defensepts;
	}
	@Override
	public int getAtackPts(){return 0;}

	public double getWeight() {
		return weight;
	}

}

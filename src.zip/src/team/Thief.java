package team;

public class Thief extends Character{

	protected int stealth;
	
	public Thief(String alias, int stealth) {
		super(alias);
		this.stealth = stealth;
	}

	@Override
	protected int getAttackPoints(){
		return super.getAttackPoints() + this.stealth;
	}
	@Override
	protected int getDefensePoints(){
		return super.getDefensePoints();
	}
	@Override
	public void attack(Character character){
		super.attack(character);
	}
	
	public void addStealth(int stealth) {
		this.stealth += stealth;
	}

}
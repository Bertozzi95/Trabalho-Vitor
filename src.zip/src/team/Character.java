package team;
/*
 * Autor: Joao Pedro Junqueira Candido - 8504094
 * 
 * agulity e power nao foram implementados pois nao estava no diagrama UML
 */
import java.util.Random;

import items.*;

abstract public class Character{
	    private int HP,MP;
	    private Inventory myitems;
	    private String alias;
	    private static Random rand = new Random();
	    
	    protected int XP,strenght,speed,dexterity,constitution;
	    protected double modifiedSpeed;
	    

	public int getStrenght() {
			return strenght;
	}
	public int getSpeed() {
			return speed;
	}
		public int getDexterity() {
			return dexterity;
	}
	public int getConstitution() {
			return constitution;
	}
	public double getModifiedSpeed() {
			return modifiedSpeed;
	}
	public Character(String alias){
		this.HP = 100;
		this.XP = 0;
		this.alias=alias;
		myitems = new Inventory(this);
		System.out.println("O poderoso "+alias+" foi criado");
	}
	public String getName(){
		return this.alias;
	}
	
	/*
	 * calcula se o char errou o ataque (.1*XP de chance)
	 * senao, calcula se o char deu dano critico (.02*XP/2 de chance)
	 * senao calcula o dano normal com base na equacao dada
	 */
	public void attack(Character character){
		int newHP = ((int) (this.getAttackPoints() - character.getDefensePoints()) + rnd(-5,5));
		newHP = newHP<=0?1:newHP;
		int missChance = (int) (0.1*this.XP)*100;
		int criticalChance = (int) (0.02*(this.XP/2)*100);
		if(rnd(0,missChance)==0){
			newHP=0;
		}else if(rnd(0,criticalChance)==0){
			newHP *=2;
			character.loseHP(newHP);
		}else{
			character.loseHP(newHP);
		}
		System.out.println(this.alias+" fez um ataque de "+newHP+" e agora "+character.getName()+" tem "+ character.getHP() +" de HP");
		if(character.getHP()<=0){System.out.println(character.getName()+" morreu :[");}
	}
	public void addXP(int XP){
		this.XP += XP;
		System.out.println("XP:"+this.XP);
	}
	//configura a forca e divide os pontos faltantes de 100 entre as outras skills
	public void setStrenght(int strenght){
		this.strenght = (strenght>97)?97:strenght;
		this.strenght = (this.strenght<1)?1:this.strenght;
		
		this.speed = (int) (100-this.strenght)/3;
		this.dexterity = (int) (100-this.strenght)/3;
		this.constitution = 100-(this.speed + this.dexterity + this.strenght);
		
		System.out.println("Str"+this.strenght+" Spd:"+this.speed+" Dex:"+this.dexterity+" Con:"+this.constitution);
	}
	//configura a velocidade e divide os pontos faltantes de 100 entre as outras skills
	public void setSpeed(int speed){
		this.speed = (speed>97)?97:speed;
		this.speed = (this.speed<1)?1:this.speed;
		
		this.strenght = (int) (100-this.speed)/3;
		this.dexterity = (int) (100-this.speed)/3;
		this.constitution = 100-(this.speed + this.dexterity + this.strenght);
		
		System.out.println("Str"+this.strenght+" Spd:"+this.speed+" Dex:"+this.dexterity+" Con:"+this.constitution);
	}
	public void setModifiedSpeed(double speed){
		this.modifiedSpeed = speed;
	}
	//configura a destreza e divide os pontos faltantes de 100 entre as outras skills
	public void setDexterity(int dexterity){
		this.dexterity = (dexterity>97)?97:dexterity;
		this.dexterity = (this.dexterity<1)?1:this.dexterity;
		
		this.speed = (int) (100-this.dexterity)/3;
		this.strenght = (int) (100-this.dexterity)/3;
		this.constitution = 100-(this.speed + this.dexterity + this.strenght);
		
		System.out.println("Str"+this.strenght+" Spd:"+this.speed+" Dex:"+this.dexterity+" Con:"+this.constitution);
		}
	//configura a constituicao e divide os pontos faltantes de 100 entre as outras skills
	public void setConstitution(int constitution){
		this.constitution = (constitution>97)?97:constitution;
		this.constitution = (this.constitution<1)?1:this.constitution;
		
		this.speed = (int) (100-this.constitution)/3;
		this.dexterity = (int) (100-this.constitution)/3;
		this.strenght = 100-(this.speed + this.dexterity + this.constitution);
		
		System.out.println("Str"+this.strenght+" Spd:"+this.speed+" Dex:"+this.dexterity+" Con:"+this.constitution);
		}
	
	//calcula os pontos de defesa levando em consideracao as armaduras equipadas do personagem
	protected int getDefensePoints(){
		int itemDefPts=0;
		Item item;
		for(int i=0;i<myitems.numberOfItems();i++){
			item = myitems.searchItem(i);
			if (item instanceof Armor && myitems.isEquiped(item)) {
				Armor armor = (Armor) myitems.searchItem(i);
				itemDefPts+=armor.getDefensePts();
			}
		}
		int def = (int) ((constitution*.5 + dexterity*.3 + modifiedSpeed*.2)+itemDefPts)*(XP/2);
		return def;
	}
	//calcula os pontos de ataque levando em consideracao as armas equipadas do personagem
	protected int getAttackPoints(){
		int itemAttPts=0;
		Item item;
		for(int i=0;i<myitems.numberOfItems();i++){
			item = myitems.searchItem(i);
			if(item instanceof Weapon && myitems.isEquiped(item)){
				Weapon weapon = (Weapon) myitems.searchItem(i);
				itemAttPts+=weapon.getAtackPts();
			}
		}
		int att = (int) ((strenght*.5 + dexterity*.3 + modifiedSpeed*.2)+itemAttPts)*(XP/3);
		return att;
	}
	public int getMP(){
		return this.MP;
	}
	public void addMP(int MP){
		this.MP += MP;
	}
	public void addHP(int HP){
		this.HP += HP;
	}
	public void loseHP(int HP){
		this.HP -= HP;
	}
	public int getHP(){
		return this.HP;
	}
	public void addItem(Item item){
		this.myitems.insertItem(item);
	}
	public void setSpaces(int spaces){
		this.myitems.setSpaces(spaces);
	}
	public void deleteItem(Item item){
		this.myitems.removeItem(item.getName());
	}
	public boolean searchItem(Item item){
		return myitems.searchItem(item);
	}
	public void equipItem(Item item){
		myitems.equip(item);
	}
	public void unequip(Item item){
		myitems.unequip(item);
	}
	//obtem um int random entre min e max
	private int rnd(int min, int max) {
	    int randomNum = rand.nextInt((max - min) + 1) + min;
	    return randomNum;
	}
	
	
}
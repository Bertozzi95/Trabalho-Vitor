package team;
import java.util.ArrayList;
import java.util.Random;

public class Team {

	private String name;
	private Color color;
	private int win, lose, draw;
	private ArrayList<Character> characters;
    private static Random rand = new Random();

	public Team(String name,Color color){
		this.name = name;
		this.color = color;
		this.characters = new ArrayList<Character>();
		System.out.println("Time "+name+" foi criado.");
	}
	
	public String getName(){
		return name;
	}
	public String getResults(){
		String result = "O score do time "+name+" (wins/draws/loses) eh: "+win+"/"+draw+"/"+lose;
		System.out.println(result);
		return result;
	}
	public void attack(Team team){
		if(Math.min(characters.size(), team.characters.size())<3){
			System.out.println("Um dos times nao possui no minimo 3 characters!");
			return;
		}
		int size = Math.max(characters.size(),team.characters.size());
		int rnd = this.rnd(0, 1);
		Team team1;
		Team team2;
		if(rnd==0){
			team1 = this;
			team2 = team;
		}else{
			team1 = team;
			team2 = this;
		}
		for(int i=0;i<size;i++){
			if(i<team1.characters.size()){
				if(i<team2.characters.size()){
					team1.characters.get(i).attack(team2.characters.get(i));
				}else{
					team1.characters.get(i).attack(team2.characters.get(i-team2.characters.size()));
				}
			}
			if(i<team2.characters.size()){
				if(i<team1.characters.size()){
					team2.characters.get(i).attack(team1.characters.get(i));
				}else{
					team2.characters.get(i).attack(team1.characters.get(i-team1.characters.size()));
				}
			}
		}
		team1.resolveBattle(team2);
		team2.resolveBattle(team1);
		team1.getResults();
		team2.getResults();
	}
	public void resolveBattle(Team team){
		if(this.getPoints() > team.getPoints()){win++;}
		else if(this.getPoints() == team.getPoints()){draw++;}
		else{lose++;}
	}
	public void addChar(Character character){
		characters.add(character);
	}
	public void removeChar(int character){
		characters.remove(character);
	}
	public void removeChar(Character character){
		characters.remove(character);
	}
	public Character searchChar(String name){
		Character character = null;
		for(int i=0;i<characters.size();i++){
			if((character = characters.get(i)).getName().equals(name)){
				return character;
			}
		}
		return character;
	}
	public int getPoints(){
		int media=0,i=0;
		for(i=0;i<characters.size();i++){
			media += characters.get(i).getHP();
		}
		media/=i;
		return media;
	}
	public String toString(){
		return "Team " + name + " de cor " + color;
	}
	//obtem um int random entre min e max
	private int rnd(int min, int max) {
	    int randomNum = rand.nextInt((max - min) + 1) + min;
	    return randomNum;
	}
}

package team;

public enum Color {
	blue,red,green,yellow,white,black
}

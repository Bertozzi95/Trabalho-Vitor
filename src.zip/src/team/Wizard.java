package team;
import Interfaces.*;
import team.Character;

public class Wizard extends Character implements Curador, Manador{

	protected int wisdom;
	
	public Wizard(String alias, int wisdom) {
		super(alias);
		this.wisdom = wisdom;
	}
	
	@Override
	protected int getDefensePoints(){
		return super.getDefensePoints() + (this.wisdom/2);
	}
	@Override
	protected int getAttackPoints(){
		return super.getAttackPoints();
	}
	@Override
	public void attack(Character character){
		super.attack(character);
	}
	
	public void addWisdom(int wisdom) {
		this.wisdom += wisdom;
	}
	
	public void cureFriend(Character friend){
		friend.addHP(wisdom*5);
		System.out.println(this.getName() + " curou " + friend.getName() + " em "+wisdom*5+" pontos de HP. Sua HP: "+friend.getHP());
	}
	public void manaFriend(Character friend){
		friend.addMP(wisdom*5);
		System.out.println(this.getName() + " deu a " + friend.getName() + " "+wisdom*5+" pontos de MP. Sua MP: "+friend.getMP());
	}

}
package team;

public class Knight extends Character{

	protected int power;
	
	public Knight(String alias, int power) {
		super(alias);
		this.power = power;
	}
	
	@Override
	protected int getDefensePoints(){
		return super.getDefensePoints() + power;
	}
	@Override
	protected int getAttackPoints(){
		return super.getAttackPoints();
	}
	@Override
	public void attack(Character character){
		super.attack(character);
	}
	
	public void addPower(int power) {
		this.power += power;
	}

}
